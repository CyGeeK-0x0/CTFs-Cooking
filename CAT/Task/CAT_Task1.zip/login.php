<?php
session_start();

$conn = mysqli_connect("db", "cat_user", "strong_password", "shop");

if (mysqli_connect_errno()) {
    die("Database connection error.");
}

if (!isset($_POST['username'], $_POST['password'])) {
    die("Invalid request.");
}

$username = trim($_POST['username']);
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT password, role FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->bind_result($pass, $role);
$stmt->fetch();
$stmt->close();

if ($pass && $password) {

    session_regenerate_id(true);

    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;

    if ($role === 'admin') {

        $flag = file_get_contents(__DIR__ . '/../flag.txt');

        echo "Login successful as admin!<br>";
        echo "Here is the flag : <strong>" . $flag . "</strong>";

    } else {
        echo "Login successful as a normal user!";
    }

} else {
    echo "Login failed";
}

$conn->close();
?>
