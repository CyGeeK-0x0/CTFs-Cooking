drop table if exists products;
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price DECIMAL(10,2)
);

INSERT INTO products (name, price)
VALUES ('Laptop', 1000), ('Phone', 500), ('PC', 2000), ('Headphone', 200), ('Keyboard', 50);

drop table if exists users;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(255),
    role VARCHAR(10)
);

INSERT INTO users (username, password, role)
VALUES ('admin', 'V3ry_D4mn_S3cure_P4ssw0rd!!', 'admin'), ('user', 'N0rmal_Us3r_P4ssw0rd!', 'user');