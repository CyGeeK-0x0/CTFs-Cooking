<?php

$conn = mysqli_connect("db", "cat_user", "strong_password", "shop");

if (mysqli_connect_errno()) {
    die("Database Connection Error. Check credentials.");
}

$search = $_GET['query'];

$sql = "SELECT * FROM products WHERE name LIKE '%$search%'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "Products found";
} else {
    echo "No products";
}
?>