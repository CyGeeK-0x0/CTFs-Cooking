### XSS Remediation :

in the "greeting.html" file replace this line of code

```js
document.write("Hello, " + name);
```

To 

```js
const escapedName = encodeURIComponent(name);
document.getElementById("greeting").textContent = "Hello, " + escapedName;
```

- Using "encodeURIComponent()" to escape/encode the chars, 
- Using "textContent" which is serfer instead of "innerhtml"


### Blind SQLi Remediation :

