drop table if exists products;
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price DECIMAL(10,2)
);

INSERT INTO products (name, price)
VALUES ('Laptop', 1000), ('Phone', 500), ('PC', 2000), ('Headphone', 200), ('Keyboard', 50);

drop table if exists users;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(255),
    role VARCHAR(10)
);

INSERT INTO users (username, password, role)
VALUES ('admin', 'V3ryS3cureP4ssw0rd', 'admin'), ('user', 'N0rmalUs3rP4ssw0rd', 'user');